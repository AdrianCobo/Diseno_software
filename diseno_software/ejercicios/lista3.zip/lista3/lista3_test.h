#ifndef LISTA1_TEST_H_INCLUDED
#define LISTA1_TEST_H_INCLUDED

#include "lista3.h"

void lista1_test1(void);

#endif // LISTA1_TEST_H_INCLUDED
