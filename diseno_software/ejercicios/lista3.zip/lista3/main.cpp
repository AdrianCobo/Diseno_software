#include <iostream>

using namespace std;

#include "lista3_test.h"

int main()
{
    lista1_test1();
    return 0;
}
